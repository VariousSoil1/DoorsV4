--This watermark is used to delete the file if its cached, remove it to make the file persist after commits.
local GuiLibrary = shared.GuiLibrary
local playersService = game:GetService("Players")
local textService = game:GetService("TextService")
local lightingService = game:GetService("Lighting")
local textChatService = game:GetService("TextChatService")
local inputService = game:GetService("UserInputService")
local runService = game:GetService("RunService")
local replicatedStorageService = game:GetService("ReplicatedStorage")
local gameCamera = workspace.CurrentCamera
local lplr = playersService.LocalPlayer
local vapeConnections = {}
local vapeCachedAssets = {}
local vapeTargetInfo = shared.VapeTargetInfo
local vapeInjected = true
local latestRoom = replicatedStorageService.GameData:FindFirstChild("LatestRoom")
table.insert(vapeConnections, workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
	gameCamera = workspace.CurrentCamera or workspace:FindFirstChildWhichIsA("Camera")
end))

local function vapeGithubRequest(scripturl)
	if not isfile("vape/"..scripturl) then
		local suc, res = pcall(function() return game:HttpGet("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/"..readfile("vape/commithash.txt").."/"..scripturl, true) end)
		assert(suc, res)
		assert(res ~= "404: Not Found", res)
		if scripturl:find(".lua") then res = "--This watermark is used to delete the file if its cached, remove it to make the file persist after commits.\n"..res end
		writefile("vape/"..scripturl, res)
	end
	return readfile("vape/"..scripturl)
end

local function warningNotification(title, text, delay)
	local suc, res = pcall(function()
		local frame = GuiLibrary.CreateNotification(title, text, delay, "assets/WarningNotification.png")
		frame.Frame.Frame.ImageColor3 = Color3.fromRGB(236, 129, 44)
		return frame
	end)
	return (suc and res)
end

local function runFunction(func) func() end

local entityLibrary = loadstring(vapeGithubRequest("Libraries/entityHandler.lua"))()
local lplr = playersService.LocalPlayer

local function isFriend(plr, recolor)
	if GuiLibrary.ObjectsThatCanBeSaved["Use FriendsToggle"].Api.Enabled then
		local friend = table.find(GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.ObjectList, plr.Name)
		friend = friend and GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.ObjectListEnabled[friend]
		if recolor then
			friend = friend and GuiLibrary.ObjectsThatCanBeSaved["Recolor visualsToggle"].Api.Enabled
		end
		return friend
	end
	return nil
end

local function isTarget(plr)
	local friend = table.find(GuiLibrary.ObjectsThatCanBeSaved.TargetsListTextCircleList.Api.ObjectList, plr.Name)
	friend = friend and GuiLibrary.ObjectsThatCanBeSaved.TargetsListTextCircleList.Api.ObjectListEnabled[friend]
	return friend
end

do
	entityLibrary.selfDestruct()
	table.insert(vapeConnections, GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.FriendRefresh.Event:Connect(function()
		entityLibrary.fullEntityRefresh()
	end))
	table.insert(vapeConnections, GuiLibrary.ObjectsThatCanBeSaved["Teams by colorToggle"].Api.Refresh.Event:Connect(function()
		entityLibrary.fullEntityRefresh()
	end))
	local oldUpdateBehavior = entityLibrary.getUpdateConnections
	entityLibrary.getUpdateConnections = function(newEntity)
		local oldUpdateConnections = oldUpdateBehavior(newEntity)
		table.insert(oldUpdateConnections, {Connect = function() 
			newEntity.Friend = isFriend(newEntity.Player) and true
			newEntity.Target = isTarget(newEntity.Player) and true
			return {Disconnect = function() end}
		end})
		return oldUpdateConnections
	end
	entityLibrary.isPlayerTargetable = function(plr)
		if isFriend(plr) then return false end
		if (not GuiLibrary.ObjectsThatCanBeSaved["Teams by colorToggle"].Api.Enabled) then return true end
		if (not lplr.Team) then return true end
		if (not plr.Team) then return true end
		if plr.Team ~= lplr.Team then return true end
		return #plr.Team:GetPlayers() == playersService.NumPlayers
	end
	entityLibrary.fullEntityRefresh()
	entityLibrary.LocalPosition = Vector3.zero

	task.spawn(function()
		local postable = {}
		repeat
			task.wait()
			if entityLibrary.isAlive then
				table.insert(postable, {Time = tick(), Position = entityLibrary.character.HumanoidRootPart.Position})
				if #postable > 100 then 
					table.remove(postable, 1)
				end
				local closestmag = 9e9
				local closestpos = entityLibrary.character.HumanoidRootPart.Position
				for i, v in pairs(postable) do 
					local mag = math.abs(tick() - (v.Time + 0.1))
					if mag < closestmag then
						closestmag = mag
						closestpos = (postable[i - 1] or v).Position:lerp(v.Position, 0.85)
					end
				end
				entityLibrary.LocalPosition = closestpos
			end
		until not vapeInjected
	end)
end

local RunLoops = {RenderStepTable = {}, StepTable = {}, HeartTable = {}}
do
	function RunLoops:BindToRenderStep(name, func)
		if RunLoops.RenderStepTable[name] == nil then
			RunLoops.RenderStepTable[name] = runService.RenderStepped:Connect(func)
		end
	end

	function RunLoops:UnbindFromRenderStep(name)
		if RunLoops.RenderStepTable[name] then
			RunLoops.RenderStepTable[name]:Disconnect()
			RunLoops.RenderStepTable[name] = nil
		end
	end

	function RunLoops:BindToStepped(name, func)
		if RunLoops.StepTable[name] == nil then
			RunLoops.StepTable[name] = runService.Stepped:Connect(func)
		end
	end

	function RunLoops:UnbindFromStepped(name)
		if RunLoops.StepTable[name] then
			RunLoops.StepTable[name]:Disconnect()
			RunLoops.StepTable[name] = nil
		end
	end

	function RunLoops:BindToHeartbeat(name, func)
		if RunLoops.HeartTable[name] == nil then
			RunLoops.HeartTable[name] = runService.Heartbeat:Connect(func)
		end
	end

	function RunLoops:UnbindFromHeartbeat(name)
		if RunLoops.HeartTable[name] then
			RunLoops.HeartTable[name]:Disconnect()
			RunLoops.HeartTable[name] = nil
		end
	end
end

runFunction(function()
	local DoorsSpeed = {Enabled = false}
	local DoorsSpeedValue = {Value = 1}
	local DoorsSpeedMethod = {Value = "AntiCheat A"}
	local DoorsSpeedMoveMethod = {Value = "MoveDirection"}
	local oldWalkSpeed

	local alternatelist = {"Normal", "AntiCheat A", "AntiCheat B"}
	DoorsSpeed = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "DoorsSpeed", 
		Function = function(callback)
			if callback then
				RunLoops:BindToHeartbeat("DoorsSpeed", function(delta)
					if entityLibrary.isAlive and (typeof(entityLibrary.character.HumanoidRootPart) ~= "Instance" or isnetworkowner(entityLibrary.character.HumanoidRootPart)) then
						if DoorsSpeedMethod.Value == "WalkSpeed" then 
							if oldWalkSpeed == nil then
								oldWalkSpeed = entityLibrary.character.Humanoid.WalkSpeed
							end
							entityLibrary.character.Humanoid.WalkSpeed = DoorsSpeedValue.Value
						elseif DoorsSpeedMethod.Value == "Doors" then
							lplr.Character:TranslateBy(lplr.Character.Humanoid.MoveDirection * 0.6 * delta * 10)
						end
					end
				end)
			else
				if oldWalkSpeed then
					entityLibrary.character.Humanoid.WalkSpeed = oldWalkSpeed
					oldWalkSpeed = nil
				end
				RunLoops:UnbindFromHeartbeat("DoorsSpeed")
			end
		end,
		ExtraText = function() 
			if GuiLibrary.ObjectsThatCanBeSaved["Text GUIAlternate TextToggle"].Api.Enabled then 
				return alternatelist[table.find(DoorsSpeedMethod.List, DoorsSpeedMethod.Value)]
			end
			return DoorsSpeedMethod.Value
		end
	})
	DoorsSpeedMethod = DoorsSpeed.CreateDropdown({
		Name = "Mode", 
		List = {"WalkSpeed", "Doors"},
		Function = function(val)
			if oldWalkSpeed then
				entityLibrary.character.Humanoid.WalkSpeed = oldWalkSpeed
				oldWalkSpeed = nil
			end
		end
	})
	DoorsSpeedMoveMethod = DoorsSpeed.CreateDropdown({
		Name = "Movement", 
		List = {"Manual", "MoveDirection"},
		Function = function(val) end
	})
	DoorsSpeedValue = DoorsSpeed.CreateSlider({
		Name = "Speed", 
		Min = 1,
		Max = 21, 
		Function = function(val) end
	})
end)

runFunction(function()
	local InstantProximityPrompt = {Enabled = false}
	local Connection = game:GetService("ProximityPromptService").PromptButtonHoldBegan
	
	InstantProximityPrompt = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "InstantProximityPrompt",
		Function = function(callback)
			table.insert(vapeConnections, Connection:Connect(function(p)
				if callback then
					fireproximityprompt(p)
				end
			end))
		end,
		HoverText = "interacts with stuff instantly",
	})
end)

runFunction(function()
	local DoorNotifier = {Enabled = false}
	
	DoorNotifier = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "DoorNotifier",
		Function = function(callback)
			table.insert(vapeConnections, latestRoom:GetPropertyChangedSignal("Value"):Connect(function()
				if callback and latestRoom.Value ~= 100 then
					warningNotification("DoorNotifier", "next door: "..latestRoom.Value + 1, 2)
				end
			end))
		end,
		HoverText = "gives you basic information",
	})
end)

runFunction(function()
	local MonsterNotifier = {Enabled = false}
	local RushMoving = false
	local AmbushMoving = false
	local ScreechSpawned = false

	MonsterNotifier = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "MonsterNotifier",
		Function = function(callback)
			if callback then
				RunLoops:BindToHeartbeat("MonsterNotifier", function()
					for i,v in pairs(workspace:GetChildren()) do
						if v.Name == "RushMoving" and v.PrimaryPart ~= nil and not RushMoving and v.PrimaryPart.Position.Y > -100 then
							warningNotification("MonsterNotifier", v.Name.."/"..v.PrimaryPart.Name.." has spawned, go hide lol. ", 5)
							repeat task.wait()
								RushMoving = true
							until not v.PrimaryPart
							RushMoving = false
						elseif v.Name == "AmbushMoving" and v.PrimaryPart ~= nil and not AmbushMoving and v.PrimaryPart.Position.Y > -100 then
							warningNotification("MonsterNotifier", v.Name.." has spawned, go hide lol. ", 5)
							repeat task.wait()
								AmbushMoving = true
							until not v.PrimaryPart
							AmbushMoving = false
						end
					end
					for i,v in pairs(gameCamera:GetChildren()) do
						if v.Name == "Screech" and not ScreechSpawned then
							warningNotification("MonsterNotifier", "Screech has spawned, look at it! ", 5)
							repeat task.wait()
								ScreechSpawned = true
							until not v.PrimaryPart
							ScreechSpawned = false
						end
					end
				end)
			else
				RunLoops:UnbindFromHeartbeat("MonsterNotifier")
			end
		end,
		HoverText = "notifies you when an entity spawns",
	})
end)

runFunction(function()
	local WasteOthersItems = {Enabled = false}
	
	WasteOthersItems = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "WasteOthersItems",
		Function = function(callback)
			if callback then
				RunLoops:BindToHeartbeat("WasteOthersItems", function()
					for i,v in pairs(playersService:GetPlayers()) do
						if v:GetAttribute("Alive") and v ~= lplr then
							for i,item in pairs(v.Backpack:GetDescendants()) do
								if item.Name == "Remote" then
									item:FireServer()
								end
							end
							
							for i,item in pairs(v.Character:GetDescendants()) do
								if item.Name == "Remote" then
									item:FireServer()
								end
							end
						end
					end
				end)
			else
				RunLoops:UnbindFromHeartbeat("WasteOthersItems")
			end
		end,
		HoverText = "ruin players experiences by wasting all of their items",
	})
end)

runFunction(function()
	local BananaSpam = {Enabled = false}

	local function GetBananas()
		local Bananas = {}
		for i,v in pairs(workspace:GetChildren()) do
			if v.Name == "BananaPeel" then
				table.insert(Bananas, v)
			end
		end
		return Bananas
	end

	local function GetRandomPlayer()
		local Players = game.Players:GetPlayers()
		local PlayerTable = {}
		
		for i,v in pairs(Players) do
			if v:GetAttribute("Alive") and v.Name ~= game.Players.LocalPlayer.Name then
				table.insert(PlayerTable, v)
			end
			if #PlayerTable == 1 then
				return game.Players.LocalPlayer
			elseif #PlayerTable == 0 then
				return "stop"
			else
				return PlayerTable[math.random(1, #PlayerTable)]
			end
		end
	end

	BananaSpam = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "BananaSpam",
		Function = function(callback)
			if callback then
				RunLoops:BindToHeartbeat("BananaSpam", function()
					local Bananas = GetBananas()
		
					for _, Banana in next, Bananas do
						Banana.Velocity = Vector3.new(0,-5,0)
					end
		
					for _, Banana in next, Bananas do
						if isnetworkowner(Banana) then
							if GetRandomPlayer() == "stop" then
								RunLoops:UnbindFromHeartbeat()
							end
							if GetRandomPlayer ~= nil and GetRandomPlayer().Character then
								Banana.CFrame = GetRandomPlayer().Character.PrimaryPart.CFrame
							end
						end
					end
				end)
			else
				RunLoops:UnbindFromHeartbeat("BananaSpam")
			end
		end,
		HoverText = "spam bananas and possibly kill someone",
	})
end)

runFunction(function()
	local Announcer = {Enabled = false}
	local RushMoving = false
	local AmbushMoving = false
	
	Announcer = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
		Name = "Announcer",
		Function = function(callback)
			repeat
				task.wait()
				for i,v in pairs(workspace:GetChildren()) do
					if v.Name == "RushMoving" and v.PrimaryPart ~= nil and not RushMoving and v.PrimaryPart.Position.Y > -100 then
						textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(("Rush is coming, hide!"))
						repeat task.wait() RushMoving = true until not v.PrimaryPart
						RushMoving = false
					elseif v.Name == "AmbushMoving" and v.PrimaryPart ~= nil and not AmbushMoving and v.PrimaryPart.Position.Y > -100 then
						textChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(("Ambush is coming, hide!"))
						repeat task.wait() AmbushMoving = true until not v.PrimaryPart
						AmbushMoving = false
					end
				end
			until not Announcer.Enabled
		end,
		HoverText = "announces things to other players",
	})
end)

runFunction(function()
	local CompleteElevatorBroker = {Enabled = false}
	CompleteElevatorBroker = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "CompleteElevatorBroker",
		Function = function(callback)
			if callback then
				replicatedStorageService.EntityInfo.EBF:FireServer()
				CompleteElevatorBroker.ToggleButton(false)
			end
		end,
		HoverText = "automatically completes the elevator broker at door 100",
	})
end)

runFunction(function()
	local DisableSeek = {Enabled = false}
	
	DisableSeek = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "DisableSeek",
		Function = function(callback)
			table.insert(vapeConnections, latestRoom:GetPropertyChangedSignal("Value"):Connect(function()
				if callback then
					pcall(function()
						for i,v in pairs(workspace.CurrentRooms[latestRoom.Value]:GetDescendants()) do
							if v.Name == "TriggerSeek" or v.Name == "TriggerEventCollision" then
								v:Destroy()
								warningNotification("DisableSeek", "Seek disabled", 5)
							end
						end
					end)
				end
			end))
		end,
		HoverText = "disables seek entirely",
	})
end)

runFunction(function()
	local OpenDoorsFarther = {Enabled = false}

	OpenDoorsFarther = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "OpenDoorsFarther",
		Function = function(callback)
			repeat
				pcall(function()
					for i,v in pairs(workspace.CurrentRooms[latestRoom.Value]:GetDescendants()) do
						if v.Name == "ClientOpen" then
							v:FireServer()
						end
					end
				end)
				task.wait(1)
			until not OpenDoorsFarther.Enabled
		end,
		HoverText = "open doors from really far away"
	})
end)
