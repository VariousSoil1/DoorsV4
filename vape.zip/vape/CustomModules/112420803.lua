--This watermark is used to delete the file if its cached, remove it to make the file persist after commits.
local GuiLibrary = shared.GuiLibrary
local playersService = game:GetService("Players")
local textService = game:GetService("TextService")
local lightingService = game:GetService("Lighting")
local textChatService = game:GetService("TextChatService")
local inputService = game:GetService("UserInputService")
local runService = game:GetService("RunService")
local replicatedStorageService = game:GetService("ReplicatedStorage")
local gameCamera = workspace.CurrentCamera
local lplr = playersService.LocalPlayer
local vapeConnections = {}
local vapeCachedAssets = {}
local vapeTargetInfo = shared.VapeTargetInfo
local vapeInjected = true
table.insert(vapeConnections, workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
	gameCamera = workspace.CurrentCamera or workspace:FindFirstChildWhichIsA("Camera")
end))

local function vapeGithubRequest(scripturl)
	if not isfile("vape/"..scripturl) then
		local suc, res = pcall(function() return game:HttpGet("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/"..readfile("vape/commithash.txt").."/"..scripturl, true) end)
		assert(suc, res)
		assert(res ~= "404: Not Found", res)
		if scripturl:find(".lua") then res = "--This watermark is used to delete the file if its cached, remove it to make the file persist after commits.\n"..res end
		writefile("vape/"..scripturl, res)
	end
	return readfile("vape/"..scripturl)
end

local function warningNotification(title, text, delay)
	local suc, res = pcall(function()
		local frame = GuiLibrary.CreateNotification(title, text, delay, "assets/WarningNotification.png")
		frame.Frame.Frame.ImageColor3 = Color3.fromRGB(236, 129, 44)
		return frame
	end)
	return (suc and res)
end

local function runFunction(func) func() end

local entityLibrary = loadstring(vapeGithubRequest("Libraries/entityHandler.lua"))()
local lplr = playersService.LocalPlayer

local function isFriend(plr, recolor)
	if GuiLibrary.ObjectsThatCanBeSaved["Use FriendsToggle"].Api.Enabled then
		local friend = table.find(GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.ObjectList, plr.Name)
		friend = friend and GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.ObjectListEnabled[friend]
		if recolor then
			friend = friend and GuiLibrary.ObjectsThatCanBeSaved["Recolor visualsToggle"].Api.Enabled
		end
		return friend
	end
	return nil
end

local function isTarget(plr)
	local friend = table.find(GuiLibrary.ObjectsThatCanBeSaved.TargetsListTextCircleList.Api.ObjectList, plr.Name)
	friend = friend and GuiLibrary.ObjectsThatCanBeSaved.TargetsListTextCircleList.Api.ObjectListEnabled[friend]
	return friend
end

do
	entityLibrary.selfDestruct()
	table.insert(vapeConnections, GuiLibrary.ObjectsThatCanBeSaved.FriendsListTextCircleList.Api.FriendRefresh.Event:Connect(function()
		entityLibrary.fullEntityRefresh()
	end))
	table.insert(vapeConnections, GuiLibrary.ObjectsThatCanBeSaved["Teams by colorToggle"].Api.Refresh.Event:Connect(function()
		entityLibrary.fullEntityRefresh()
	end))
	local oldUpdateBehavior = entityLibrary.getUpdateConnections
	entityLibrary.getUpdateConnections = function(newEntity)
		local oldUpdateConnections = oldUpdateBehavior(newEntity)
		table.insert(oldUpdateConnections, {Connect = function() 
			newEntity.Friend = isFriend(newEntity.Player) and true
			newEntity.Target = isTarget(newEntity.Player) and true
			return {Disconnect = function() end}
		end})
		return oldUpdateConnections
	end
	entityLibrary.isPlayerTargetable = function(plr)
		if isFriend(plr) then return false end
		if (not GuiLibrary.ObjectsThatCanBeSaved["Teams by colorToggle"].Api.Enabled) then return true end
		if (not lplr.Team) then return true end
		if (not plr.Team) then return true end
		if plr.Team ~= lplr.Team then return true end
        return #plr.Team:GetPlayers() == playersService.NumPlayers
	end
	entityLibrary.fullEntityRefresh()
	entityLibrary.LocalPosition = Vector3.zero

	task.spawn(function()
		local postable = {}
		repeat
			task.wait()
			if entityLibrary.isAlive then
				table.insert(postable, {Time = tick(), Position = entityLibrary.character.HumanoidRootPart.Position})
				if #postable > 100 then 
					table.remove(postable, 1)
				end
				local closestmag = 9e9
				local closestpos = entityLibrary.character.HumanoidRootPart.Position
				for i, v in pairs(postable) do 
					local mag = math.abs(tick() - (v.Time + 0.1))
					if mag < closestmag then
						closestmag = mag
						closestpos = (postable[i - 1] or v).Position:lerp(v.Position, 0.85)
					end
				end
				entityLibrary.LocalPosition = closestpos
			end
		until not vapeInjected
	end)
end

local RunLoops = {RenderStepTable = {}, StepTable = {}, HeartTable = {}}
do
	function RunLoops:BindToRenderStep(name, func)
		if RunLoops.RenderStepTable[name] == nil then
			RunLoops.RenderStepTable[name] = runService.RenderStepped:Connect(func)
		end
	end

	function RunLoops:UnbindFromRenderStep(name)
		if RunLoops.RenderStepTable[name] then
			RunLoops.RenderStepTable[name]:Disconnect()
			RunLoops.RenderStepTable[name] = nil
		end
	end

	function RunLoops:BindToStepped(name, func)
		if RunLoops.StepTable[name] == nil then
			RunLoops.StepTable[name] = runService.Stepped:Connect(func)
		end
	end

	function RunLoops:UnbindFromStepped(name)
		if RunLoops.StepTable[name] then
			RunLoops.StepTable[name]:Disconnect()
			RunLoops.StepTable[name] = nil
		end
	end

	function RunLoops:BindToHeartbeat(name, func)
		if RunLoops.HeartTable[name] == nil then
			RunLoops.HeartTable[name] = runService.Heartbeat:Connect(func)
		end
	end

	function RunLoops:UnbindFromHeartbeat(name)
		if RunLoops.HeartTable[name] then
			RunLoops.HeartTable[name]:Disconnect()
			RunLoops.HeartTable[name] = nil
		end
	end
end

local gameFolder = workspace.Terrain:FindFirstChild("_Game")

runFunction(function()
    local PermanentAdmin = {Enabled = false}
    local HasAdmin = false

    PermanentAdmin = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
        Name = "PermanentAdmin",
        Function = function(callback)
            if callback then
                RunLoops:BindToHeartbeat("PermanentAdmin", function()
                    for i,v in pairs(gameFolder.Admin.Pads:GetChildren()) do
                        if v.Name == lplr.Name.."'s admin" then
                            HasAdmin = true
                            break
                        else
                            HasAdmin = false
                        end
                    end
                    for i,v in pairs(gameFolder.Admin.Pads:GetChildren()) do
                        if v.Name == "Touch to get admin" and not HasAdmin then
                            firetouchinterest(lplr.Character.PrimaryPart, v.Head, 0)
                            task.wait()
                            firetouchinterest(lplr.Character.PrimaryPart, v.Head, 1)
                            HasAdmin = true
                        end
                    end
                end)
            else
                RunLoops:UnbindFromHeartbeat("PermanentAdmin")
            end
        end,
        HoverText = "get admin instantly",
    })
end)

runFunction(function()
    local Padban = {Enabled = false}
    local PlayerToPadban = {Value = ""}
    local finished = false

    Padban = GuiLibrary.ObjectsThatCanBeSaved.BlatantWindow.Api.CreateOptionsButton({
        Name = "Padban",
        Function = function(callback)
            if callback then
                warningNotification("Padban", "Padbanning "..PlayerToPadban.Value, 5)
                for i=1,100 do
                    task.wait()
                    playersService:Chat("dog "..PlayerToPadban.Value)
                end
                playersService:Chat("kill "..PlayerToPadban.Value)
                Padban.ToggleButton(false)
            end
        end,
        HoverText = "remove their ability to get admin for 10 mins",
    })

    PlayerToPadban = Padban.CreateTextBox({
        Name = "Player",
        TempText = "Player (can be shortened)",
        Function = function(enter)
            if enter and Padban.Enabled then
                Padban.ToggleButton(false)
                Padban.ToggleButton(false)
            end
        end,
    })
end)

runFunction(function()
    local DisableKillbricks = {Enabled = false}
	local DisableParts = Instance.new("Folder", nil)

    DisableKillbricks = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
        Name = "DisableKillbricks",
        Function = function(callback)
            if callback then
                RunLoops:BindToHeartbeat("DisableKillbricks", function()
                    for i,v in pairs(gameFolder.Workspace.Obby:GetChildren()) do
						v.Parent = DisableParts
                    end
                end)
            else
                RunLoops:UnbindFromHeartbeat("DisableKillbricks")
                for i,v in pairs(DisableParts:GetChildren()) do
                    v.Parent = gameFolder.Workspace.Obby
                end
            end
        end,
    })
end)

runFunction(function()
	local AnticheatBypass = {Enabled = false}
	local humanoidrootpart
	local clone
	local hip

	AnticheatBypass = GuiLibrary.ObjectsThatCanBeSaved.UtilityWindow.Api.CreateOptionsButton({
		Name = "AnticheatBypass",
		Function = function(callback)
			if callback then
				local function disable()
					humanoidrootpart = entityLibrary.character.HumanoidRootPart
					lplr.Parent = game
					clone = humanoidrootpart:Clone()
					lplr.Character.PrimaryPart = clone
					humanoidrootpart.Parent = gameCamera
					lplr.Character.Parent = workspace

					if hip then
						lplr.Character.Humanoid.HipHeight = hip
					end
					hip = lplr.Character.Humanoid.HipHeight
					local oldseat
					local oldseattab
					RunLoops:BindToHeartbeat("AnticheatBypass", function()
						if humanoidrootpart and clone then
							humanoidrootpart.AssemblyAngularVelocity = clone.AssemblyAngularVelocity
							humanoidrootpart.Velocity = clone.Velocity
							local sit = entityLibrary.character.Humanoid.Sit
							if sit ~= oldseat then
								oldseat = sit
							end
							local target = (clone.AssemblyAngularVelocity)
							local speed = (sit and target.Magnitude)
							target = (target.Unit == target.Unit and target.Unit or Vector3.zero) * speed
							humanoidrootpart.Velocity = Vector3.new(math.clamp(target.X, -speed, speed), clone.Velocity.Y, math.clamp(target.Z, -speed, speed))
						end
					end)
				end

				local sp
				local acconnection

				local function enable()
					task.spawn(function()
						if sp then return end
						sp = true
						shared.VapeRealCharacter = nil
						task.wait(0.4)
						lplr.Character:WaitForChild("Humanoid", 10)
						lplr.Character:WaitForChild("LeftHand", 10)
						lplr.Character:WaitForChild("RightHand", 10)
						lplr.Character:WaitForChild("LeftFoot", 10)
						lplr.Character:WaitForChild("RightFoot", 10)
						lplr.Character:WaitForChild("LeftLowerArm", 10)
						lplr.Character:WaitForChild("RightLowerArm", 10)
						lplr.Character:WaitForChild("LeftUpperArm", 10)
						lplr.Character:WaitForChild("RightUpperArm", 10)
						lplr.Character:WaitForChild("LeftLowerLeg", 10)
						lplr.Character:WaitForChild("RightLowerLeg", 10)
						lplr.Character:WaitForChild("LeftUpperLeg", 10)
						lplr.Character:WaitForChild("RightUpperLeg", 10)
						lplr.Character:WaitForChild("UpperTorso", 10)
						lplr.Character:WaitForChild("LowerTorso", 10)
						local root = lplr.Character:WaitForChild("HumanoidRootPart", 20)
						local head = lplr.Character:WaitForChild("Head", 20)
						task.wait(0.4)
						sp = false
						if root ~= nil and head ~= nil then
							task.spawn(disable)
						end
					end)
					acconnection = lplr.CharacterAdded:Connect(function(char)
						task.spawn(function()
							if sp then return end
							sp = true
							shared.VapeRealCharacter = nil
							task.wait(0.4)
							char:WaitForChild("Humanoid", 10)
							char:WaitForChild("LeftHand", 10)
							char:WaitForChild("RightHand", 10)
							char:WaitForChild("LeftFoot", 10)
							char:WaitForChild("RightFoot", 10)
							char:WaitForChild("LeftLowerArm", 10)
							char:WaitForChild("RightLowerArm", 10)
							char:WaitForChild("LeftUpperArm", 10)
							char:WaitForChild("RightUpperArm", 10)
							char:WaitForChild("LeftLowerLeg", 10)
							char:WaitForChild("RightLowerLeg", 10)
							char:WaitForChild("LeftUpperLeg", 10)
							char:WaitForChild("RightUpperLeg", 10)
							char:WaitForChild("UpperTorso", 10)
							char:WaitForChild("LowerTorso", 10)
							local root = char:WaitForChild("HumanoidRootPart", 20)
							local head = char:WaitForChild("Head", 20)
							task.wait(0.4)
							sp = false
							if root ~= nil and head ~= nil then
								task.spawn(disable)
							end
						end)
					end)
				end
				task.spawn(enable)
			else
				if acconnection then acconnection:Disconnect() end
				RunLoops:UnbindFromHeartbeat("AnticheatBypass")
				if humanoidrootpart and clone and lplr.Character.Parent == workspace and humanoidrootpart.Parent ~= nil then
					lplr.Character.Parent = game
					humanoidrootpart.Parent = lplr.Character
					lplr.Character.PrimaryPart = humanoidrootpart
					lplr.Character.Parent = workspace
					if clone then clone:Destroy() end
					humanoidrootpart = nil
				end
			end
		end,
		HoverText = "idk",
	})
end)
